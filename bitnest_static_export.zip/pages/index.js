import React from 'react';
export default function Home() {
  return (
    <div>
      <h1>Welcome to BitNest</h1>
      <p>The most trusted crypto investment platform with over 1 million users.</p>
    </div>
  );
}