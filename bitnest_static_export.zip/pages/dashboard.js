import React from 'react';
export default function Dashboard() {
  return <div>User Dashboard with balance and deposit options</div>;
}